module.exports = function (app) {
    app.get('/', function (req, res) {
        res.render('index');
    });
    
    app.get('/timeTable', function (req, res) {
        res.render('timeTable');
    });

    app.get('/memberList', function (req, res) {
        res.render('memberList');
    });

    app.get('/mary', function (req, res) {
        res.render('maryStore');
    });

    app.get('/notice', function (req, res) {
        res.render('notice');
    });

    app.get('/login', function (req, res) {
        res.send('<h1>please login</h1>');
    });

    app.get('/schedule', function (req, res) {
        res.render('schedule');
    });

    app.get('/blog', function (req, res) {
        res.render('blog');
    });


}