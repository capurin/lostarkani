exports.keys = {
 clientId: "635732644944019467",
 apiKey : "AIzaSyAwQxau2WWOWdxITl97ebDc9zhCtyjBPcY",
 discordId: "NjM1NzMyNjQ0OTQ0MDE5NDY3.Xa1ZUg.h66d7oEpzeOsuxBnyHeiFhxAnf0",
 prefix: "%"
}
